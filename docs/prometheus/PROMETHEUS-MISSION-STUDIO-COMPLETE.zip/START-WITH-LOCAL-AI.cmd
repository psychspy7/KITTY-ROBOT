@echo off
cd /d "%~dp0"
py -3 launch_ai.py
pause
